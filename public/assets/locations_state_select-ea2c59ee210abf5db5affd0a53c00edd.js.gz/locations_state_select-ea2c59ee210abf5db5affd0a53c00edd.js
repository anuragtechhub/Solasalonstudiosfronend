$(function () {

  // sola state select
  $('.sola-select').each(function () {
    var $select = $(this);
    var $placeholder = $select.find('.option-placeholder');
    var $arrow = $select.find('.arrow');
    var $options = $select.find('.options');

    $select.find('.option-placeholder, .arrow').on('click', function () {
      if ($options.is(':visible')) {
        $options.hide();
        $(window).off('click.solaselect');
      } else {
        $options.show();
        $(window).on('click.solaselect', function () {
          $options.hide();
        });
      }
      return false;
    });

    $select.find('.option').on('click', function (event) {
      //var $this = $(this);
      // if (console && typeof console.log == 'function') {
      //   console.log($(this).data('value'));
      // }
      window.location.href = $(this).data('value');
      return false;
    });

  });
  
});
